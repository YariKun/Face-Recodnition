# Проект: Mood extention

## **Описание**

Это проект представляет собой расширение для браузера, которое показывает настроение аудиториию. Используется библиотека для создания графиков Chart.js.


# **Установка и запуск проекта**

1.  Клонировать репозиторий:

    git clone https://github.com/NataliaRom1/mood_extention.git

2.  Ввести chrome://extensions в браузере, чтобы открыть Chrome Extensions Manager;

3.  Включить "Developer mode" в правом верхнем углу;

4.  Затем нажмите Load unpacked и укажите папку, в которой находится расширение с файлом manifest.json (папка mood_extention).


## **Автор**

**_Наталья Романовская_**

- Telegram: [@Natalia_Romanovskaia](https://t.me/Natalia_Romanovskaia)
- GitHub: [@NataliaRom1](https://github.com/NataliaRom1)



